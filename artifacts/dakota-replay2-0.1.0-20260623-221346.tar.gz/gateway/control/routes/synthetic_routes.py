"""API completa de synthetic para o dashboard web.

Cobre todos os comandos CLI:
  analyze-source, screens, generate, stress,
  journey infer/infer-menu/list/show/run,
  error-patterns, diff, report
"""
from __future__ import annotations

import json
import threading
from urllib.parse import parse_qs


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_json(handler, status_code: int, payload) -> None:
    handler.send_response(status_code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.end_headers()
    handler.wfile.write(json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"))


def _read_body(handler) -> dict:
    content_len = int(handler.headers.get("Content-Length", 0))
    if content_len:
        return json.loads(handler.rfile.read(content_len))
    return {}


# ---------------------------------------------------------------------------
# GET routes
# ---------------------------------------------------------------------------

def handle_synthetic_get_route(handler, parsed_path) -> bool:
    path = parsed_path.path
    qs = parse_qs(parsed_path.query or "")

    # --- Screens ---
    if path == "/api/synthetic/screens":
        con = handler._db()
        try:
            from dakota_gateway.synthetic.screen_registry import ScreenRegistry
            reg = ScreenRegistry(con)
            screens = reg.list_screens()
            result = []
            for s in screens:
                fields = reg.get_fields_by_screen(s.id)
                result.append({
                    "id": s.id,
                    "signature": s.screen_signature,
                    "title": s.title,
                    "program": s.program_name,
                    "created_at": s.created_at,
                    "fields": [
                        {"name": f.field_name, "datatype": f.datatype, "required": f.required}
                        for f in fields
                    ],
                })
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {"screens": result})
        return True

    if path.startswith("/api/synthetic/screens/") and path.count("/") == 4:
        screen_id = int(path.split("/")[4])
        con = handler._db()
        try:
            from dakota_gateway.synthetic.screen_registry import ScreenRegistry
            reg = ScreenRegistry(con)
            schema = reg.get_screen_schema(screen_id)
            if not schema:
                _write_json(handler, 404, {"error": "screen not found"})
                return True
            result = {
                "screen_id": schema.screen_id,
                "signature": schema.screen_signature,
                "title": schema.title,
                "program": schema.program_name,
                "fields": [
                    {"name": f.name, "datatype": f.datatype, "required": f.required,
                     "unique": f.unique, "lookup": f.lookup, "format": f.format}
                    for f in schema.fields
                ],
            }
        finally:
            handler._db_release(con)
        _write_json(handler, 200, result)
        return True

    # --- Datasets ---
    if path == "/api/synthetic/datasets":
        con = handler._db()
        try:
            rows = con.execute(
                "SELECT id, name, screen_id, entity_name, quantity, seed, created_at FROM synthetic_datasets ORDER BY id DESC LIMIT 100"
            ).fetchall()
            result = [dict(r) for r in rows]
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {"datasets": result})
        return True

    if path.startswith("/api/synthetic/datasets/") and path.count("/") == 4:
        ds_id = int(path.split("/")[4])
        con = handler._db()
        try:
            from dakota_gateway.synthetic.engine import SyntheticEngine
            engine = SyntheticEngine(db_connection=con)
            dataset = engine.load_dataset(ds_id)
            if not dataset:
                _write_json(handler, 404, {"error": "dataset not found"})
                return True
            result = {
                "id": ds_id, "name": dataset.name,
                "screen_id": dataset.screen_id, "entity_name": dataset.entity_name,
                "quantity": dataset.quantity, "seed": dataset.seed,
                "created_at": dataset.created_at,
                "records_sample": [
                    r.data for r in (dataset.records[:5] if dataset.records else [])
                ],
            }
        finally:
            handler._db_release(con)
        _write_json(handler, 200, result)
        return True

    # --- Entities ---
    if path == "/api/synthetic/entities":
        con = handler._db()
        try:
            rows = con.execute(
                "SELECT id, name, storage_type, source, created_at FROM source_entities ORDER BY name"
            ).fetchall()
            result = []
            for r in rows:
                fields = con.execute(
                    "SELECT field_name, datatype, required, unique_flag FROM source_entity_fields WHERE entity_id=?",
                    (r["id"],),
                ).fetchall()
                result.append({
                    "id": r["id"], "name": r["name"],
                    "storage_type": r["storage_type"], "source": r["source"],
                    "created_at": r["created_at"],
                    "fields": [dict(f) for f in fields],
                })
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {"entities": result})
        return True

    # --- Journeys (list, show, verify, report) ---
    if path == "/api/synthetic/journeys":
        con = handler._db()
        try:
            from dakota_gateway.synthetic.journey_builder import JourneyBuilder
            builder = JourneyBuilder(db_connection=con)
            journeys = builder.list_journeys()
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {"journeys": journeys})
        return True

    if path.startswith("/api/synthetic/journeys/") and path.count("/") == 4:
        journey_id = path.split("/")[4]
        con = handler._db()
        try:
            from dakota_gateway.synthetic.journey_builder import JourneyBuilder
            builder = JourneyBuilder(db_connection=con)
            journey = builder.load_journey(journey_id)
        finally:
            handler._db_release(con)
        if not journey:
            _write_json(handler, 404, {"error": "journey not found"})
        else:
            _write_json(handler, 200, journey.to_dict())
        return True

    if path.startswith("/api/synthetic/journeys/") and path.endswith("/verify"):
        parts = path.split("/")
        if len(parts) < 6:
            _write_json(handler, 404, {"error": "invalid path"})
            return True
        journey_id = parts[4]
        sessions = int((qs.get("sessions") or ["5"])[0])
        seed = int((qs.get("seed") or ["0"])[0])
        con = handler._db()
        try:
            from dakota_gateway.synthetic.journey_builder import JourneyBuilder
            from dakota_gateway.synthetic.journey_verifier import JourneyVerifier
            from dakota_gateway.synthetic.stress_runner import SyntheticStressRunner
            builder = JourneyBuilder(db_connection=con)
            journey = builder.load_journey(journey_id)
            if not journey:
                _write_json(handler, 404, {"error": "journey not found"})
                return True
            jds = builder.build_journey_dataset(journey, session_count=sessions, seed=seed)
            verifier = JourneyVerifier(db_connection=con)
            all_vr = []
            results = []
            for sess_idx in range(min(sessions, jds.session_count)):
                sim = SyntheticStressRunner._simulate_screens(journey, jds, sess_idx)
                vr = verifier.verify_session(journey, sess_idx, sim)
                all_vr.append(vr)
                results.append({
                    "session": sess_idx, "passed": vr.passed,
                    "steps_passed": vr.steps_passed, "steps_failed": vr.steps_failed,
                    "errors": [{"type": e.error_type, "severity": e.severity} for e in vr.errors],
                })
            analysis = verifier.analyze_errors(all_vr)
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {"journey_id": journey_id, "sessions": results, "analysis": analysis})
        return True

    if path.startswith("/api/synthetic/journeys/") and path.endswith("/report"):
        parts = path.split("/")
        if len(parts) < 6:
            _write_json(handler, 404, {"error": "invalid path"})
            return True
        journey_id = parts[4]
        sessions = int((qs.get("sessions") or ["5"])[0])
        seed = int((qs.get("seed") or ["0"])[0])
        fmt = (qs.get("format") or ["json"])[0]
        con = handler._db()
        try:
            from dakota_gateway.synthetic.journey_builder import JourneyBuilder
            from dakota_gateway.synthetic.stress_runner import SyntheticStressRunner, SyntheticStressConfig
            from dakota_gateway.synthetic.homologation_report import HomologationReport
            builder = JourneyBuilder(db_connection=con)
            journey = builder.load_journey(journey_id)
            if not journey:
                _write_json(handler, 404, {"error": "journey not found"})
                return True
            config = SyntheticStressConfig(journey_id=journey_id, concurrency=2, max_sessions=sessions, seed=seed)
            runner = SyntheticStressRunner()
            stress_result = runner.run(config)
            report = HomologationReport(title=f"Relatório: {journey.name}")
            if fmt == "html":
                html = report.generate_html(stress_result=stress_result, journey_name=journey.name)
                handler.send_response(200)
                handler.send_header("Content-Type", "text/html; charset=utf-8")
                handler.end_headers()
                handler.wfile.write(html.encode("utf-8"))
                return True
            else:
                _write_json(handler, 200, report.generate_json(stress_result))
                return True
        finally:
            handler._db_release(con)

    # --- Error patterns ---
    if path == "/api/synthetic/error-patterns":
        from dakota_gateway.synthetic.error_detector import ErrorDetector
        detector = ErrorDetector()
        patterns = [
            {"type": etype, "severity": sev, "description": desc}
            for _, etype, sev, desc in detector._patterns
        ]
        _write_json(handler, 200, {"patterns": patterns})
        return True

    # --- Screen diff ---
    if path == "/api/synthetic/diff":
        expected = qs.get("expected", [""])[0]
        observed = qs.get("observed", [""])[0]
        from dakota_gateway.synthetic.screen_differ import ScreenDiffer
        diff = ScreenDiffer.diff(expected, observed)
        _write_json(handler, 200, ScreenDiffer.to_json(diff))
        return True

    # --- Status / summary ---
    if path == "/api/synthetic/status":
        con = handler._db()
        try:
            screens_count = con.execute("SELECT COUNT(*) as c FROM screens").fetchone()["c"]
            entities_count = con.execute("SELECT COUNT(*) as c FROM source_entities").fetchone()["c"]
            datasets_count = con.execute("SELECT COUNT(*) as c FROM synthetic_datasets").fetchone()["c"]
            journeys_count = con.execute("SELECT COUNT(*) as c FROM journeys").fetchone()["c"]
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {
            "screens": screens_count,
            "entities": entities_count,
            "datasets": datasets_count,
            "journeys": journeys_count,
        })
        return True

    # --- Metrics ---
    if path == "/api/synthetic/metrics":
        con = handler._db()
        try:
            from dakota_gateway.synthetic.csv_exporter import MetricsCollector
            metrics = MetricsCollector.collect(con)
        finally:
            handler._db_release(con)
        _write_json(handler, 200, metrics)
        return True

    return False


# ---------------------------------------------------------------------------
# POST routes
# ---------------------------------------------------------------------------

def handle_synthetic_post_route(handler, parsed_path, body: dict | None = None) -> bool:
    path = parsed_path.path
    if body is None:
        body = _read_body(handler)

    # --- Analyze source ---
    if path == "/api/synthetic/analyze-source":
        user = handler._require()
        if not user:
            return True
        source_dir = body.get("source_dir", "")
        if not source_dir:
            _write_json(handler, 400, {"error": "source_dir required"})
            return True
        con = handler._db()
        try:
            from dakota_gateway.synthetic.engine import SyntheticEngine
            engine = SyntheticEngine(db_connection=con)
            result = engine.analyze_source(source_dir)
            engine.register_screens(result)
            entities, _ = (engine.inferencer._parser.parse_all()
                           if engine.inferencer._parser else ([], []))
            engine.save_entities(entities)
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {
            "screens": len(result.screens), "entities": len(entities),
            "screens_detail": [
                {"title": s.title, "program": s.program_name, "fields": len(s.fields)}
                for s in result.screens
            ],
            "entities_detail": [
                {"name": e.name, "storage_type": e.storage_type, "fields": len(e.fields)}
                for e in entities
            ],
        })
        return True

    # --- Generate dataset ---
    if path == "/api/synthetic/generate":
        user = handler._require()
        if not user:
            return True
        screen_name = body.get("screen", body.get("screen_name", ""))
        quantity = int(body.get("quantity", 100))
        seed = int(body.get("seed", 0))
        if not screen_name:
            _write_json(handler, 400, {"error": "screen required"})
            return True
        con = handler._db()
        try:
            from dakota_gateway.synthetic.engine import SyntheticEngine
            from dakota_gateway.synthetic.screen_registry import ScreenRegistry
            engine = SyntheticEngine(db_connection=con)
            reg = ScreenRegistry(con)

            # Buscar screen por nome ou signature
            screen = reg.get_screen_by_signature(screen_name)
            if not screen:
                row = con.execute(
                    "SELECT id FROM screens WHERE title LIKE ? OR program_name LIKE ? LIMIT 1",
                    (f"%{screen_name}%", f"%{screen_name}%"),
                ).fetchone()
                if row:
                    screen = reg.get_screen_by_id(row["id"])
            if not screen:
                _write_json(handler, 404, {"error": f"screen '{screen_name}' not found"})
                return True

            dataset = engine.generate_dataset_by_screen_id(screen.id, quantity=quantity, seed=seed)
            if not dataset:
                _write_json(handler, 500, {"error": "generation failed"})
                return True

            ds_id = engine.save_dataset(dataset)
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {
            "dataset_id": ds_id,
            "name": dataset.name,
            "quantity": dataset.quantity,
            "screen_id": str(dataset.screen_id),
            "sample": [r.data for r in (dataset.records[:3] if dataset.records else [])],
        })
        return True

    # --- Run stress ---
    if path == "/api/synthetic/stress":
        user = handler._require()
        if not user:
            return True
        journey_id = body.get("scenario", body.get("journey_id", ""))
        concurrency = int(body.get("concurrency", 10))
        ramp_up = int(body.get("ramp_up", body.get("ramp_up_seconds", 5)))
        seed = int(body.get("seed", 0))
        max_sessions = int(body.get("max_sessions", body.get("sessions", 0)) or concurrency * 5)

        if not journey_id:
            _write_json(handler, 400, {"error": "scenario/journey_id required"})
            return True

        from dakota_gateway.synthetic.stress_runner import SyntheticStressRunner, SyntheticStressConfig
        config = SyntheticStressConfig(
            journey_id=journey_id, concurrency=concurrency,
            ramp_up_seconds=ramp_up, seed=seed, max_sessions=max_sessions,
        )
        runner = SyntheticStressRunner()
        result = runner.run(config)

        from dakota_gateway.synthetic.homologation_report import HomologationReport
        report = HomologationReport(title=f"Stress: {journey_id}")

        _write_json(handler, 200, {
            "status": "completed",
            "total_sessions": result.total_sessions,
            "completed": result.completed,
            "failed": result.failed,
            "errors": result.errors,
            "duration_ms": result.duration_ms,
            "duration_sec": round(result.duration_ms / 1000, 1),
            "analysis": result.aggregate_verification,
            "report": report.generate_json(result),
        })
        return True

    # --- Journey: infer ---
    if path == "/api/synthetic/journeys/infer":
        user = handler._require()
        if not user:
            return True
        source_dir = body.get("source_dir", "")
        if not source_dir:
            _write_json(handler, 400, {"error": "source_dir required"})
            return True
        from dakota_gateway.synthetic.journey_inferencer import JourneyInferencer
        inferencer = JourneyInferencer()
        journeys = inferencer.infer_from_source(source_dir)
        con = handler._db()
        try:
            from dakota_gateway.synthetic.journey_builder import JourneyBuilder
            builder = JourneyBuilder(db_connection=con)
            saved = 0
            for j in journeys:
                try:
                    builder.save_journey(j)
                    saved += 1
                except Exception:
                    pass
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {
            "inferred": len(journeys), "saved": saved,
            "journeys": [{"journey_id": j.journey_id, "name": j.name, "steps": len(j.steps)} for j in journeys],
        })
        return True

    # --- Journey: infer-menu ---
    if path == "/api/synthetic/journeys/infer-menu":
        user = handler._require()
        if not user:
            return True
        menu_file = body.get("menu_file", "")
        if not menu_file:
            _write_json(handler, 400, {"error": "menu_file required"})
            return True
        from dakota_gateway.synthetic.journey_inferencer import JourneyInferencer
        inferencer = JourneyInferencer()
        journey = inferencer.infer_from_menus(menu_file)
        if not journey:
            _write_json(handler, 400, {"error": "could not infer journey from menu"})
            return True
        con = handler._db()
        try:
            from dakota_gateway.synthetic.journey_builder import JourneyBuilder
            builder = JourneyBuilder(db_connection=con)
            jid = builder.save_journey(journey)
        finally:
            handler._db_release(con)
        _write_json(handler, 200, {"journey_id": journey.journey_id, "db_id": jid, "steps": len(journey.steps)})
        return True

    # --- Journey: run ---
    if path.startswith("/api/synthetic/journeys/") and path.endswith("/run"):
        parts = path.split("/")
        if len(parts) < 6:
            _write_json(handler, 404, {"error": "invalid path"})
            return True
        journey_id = parts[4]
        sessions = int(body.get("sessions", 10))
        seed = int(body.get("seed", 0))

        con = handler._db()
        try:
            from dakota_gateway.synthetic.journey_builder import JourneyBuilder
            from dakota_gateway.synthetic.stress_runner import SyntheticStressRunner, SyntheticStressConfig
            builder = JourneyBuilder(db_connection=con)
            journey = builder.load_journey(journey_id)
            if not journey:
                _write_json(handler, 404, {"error": "journey not found"})
                return True
            config = SyntheticStressConfig(
                journey_id=journey_id, concurrency=body.get("concurrency", 5),
                max_sessions=sessions, seed=seed,
            )
            runner = SyntheticStressRunner()
            stress_result = runner.run(config)

            # Gerar scripts de replay como amostra
            jds = builder.build_journey_dataset(journey, session_count=sessions, seed=seed)
            sample_scripts = []
            for sess_idx in range(min(3, sessions)):
                script = builder.generate_replay_script(journey, jds, session_index=sess_idx)
                sample_scripts.append(script[:500])
        finally:
            handler._db_release(con)

        _write_json(handler, 200, {
            "journey_id": journey_id,
            "journey_name": journey.name,
            "sessions": sessions,
            "completed": stress_result.completed,
            "failed": stress_result.failed,
            "analysis": stress_result.aggregate_verification,
            "sample_scripts": sample_scripts,
        })
        return True

    # --- Pipeline integrado ---
    if path == "/api/synthetic/pipeline":
        user = handler._require()
        if not user:
            return True
        source_dir = body.get("source_dir", "")
        if not source_dir:
            _write_json(handler, 400, {"error": "source_dir required"})
            return True
        sessions = int(body.get("sessions", 10))
        seed = int(body.get("seed", 0))
        save = not bool(body.get("dry_run", False))

        con = handler._db()
        try:
            from dakota_gateway.synthetic.integrated_pipeline import IntegratedPipeline
            pipeline = IntegratedPipeline(db_connection=con)
            result = pipeline.run_and_report(
                source_dir,
                save_to_db=save,
                session_count=sessions,
                seed=seed,
            )
        finally:
            handler._db_release(con)

        _write_json(handler, 200, result)
        return True

    # --- Benchmark ---
    if path == "/api/synthetic/benchmark":
        user = handler._require()
        if not user:
            return True
        name = body.get("name", "")
        journey_id = body.get("journey_id", "")
        envs = body.get("environments", [])
        if not name or not journey_id or not envs:
            _write_json(handler, 400, {"error": "name, journey_id, environments required"})
            return True
        from dakota_gateway.benchmark import BenchmarkOrchestrator, BenchmarkConfig
        config = BenchmarkConfig(
            benchmark_id=f"bench-{int(__import__('time').time())}",
            name=name,
            journey_id=journey_id,
            environments=envs,
            concurrency=int(body.get("concurrency", 5)),
            iterations=int(body.get("iterations", 3)),
            seed=int(body.get("seed", 0)),
            timeout_seconds=int(body.get("timeout", 300)),
        )
        orch = BenchmarkOrchestrator()
        report = orch.run_and_report(config)
        _write_json(handler, 200, report)
        return True

    # --- AI Assessment ---
    if path == "/api/synthetic/assess":
        user = handler._require()
        if not user:
            return True
        from dakota_gateway.assessment import AIAssessment
        assessment = AIAssessment()
        pipeline_result = body.get("pipeline_result", {})
        source_dir = body.get("source_dir", "")
        report = assessment.assess_from_pipeline(pipeline_result, source_dir)
        _write_json(handler, 200, assessment.to_dict(report))
        return True

    return False

"""Detecta operacoes CRUD completas por entidade a partir do EntityCatalog."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .entity_catalog import EntityDefinition, OperationDefinition


@dataclass
class CRUDCoverage:
    """Cobertura CRUD de uma entidade."""
    entity_name: str = ""
    has_create: bool = False
    has_read: bool = False
    has_update: bool = False
    has_delete: bool = False
    is_complete: bool = False

    create_programs: list[str] = field(default_factory=list)
    read_programs: list[str] = field(default_factory=list)
    update_programs: list[str] = field(default_factory=list)
    delete_programs: list[str] = field(default_factory=list)

    missing_operations: list[str] = field(default_factory=list)
    total_operations: int = 0


class CRUDDetector:
    """Analisa EntityDefinitions e classifica cobertura CRUD."""

    # Operacoes mapeadas para cada tipo de CRUD
    _CREATE_OPS = {"insert", "append"}
    _READ_OPS = {"select", "seek", "locate", "scatter"}
    _UPDATE_OPS = {"update", "replace", "gather"}
    _DELETE_OPS = {"delete", "pack", "zap"}

    @staticmethod
    def detect(entity: EntityDefinition) -> CRUDCoverage:
        """Analisa uma entidade e determina cobertura CRUD."""
        coverage = CRUDCoverage(entity_name=entity.name)

        source_files: set[str] = set()

        for op in entity.operations:
            op_type = str(op.operation_type or "").strip().lower()
            source_files.add(op.source_file or "")

            if op_type in CRUDDetector._CREATE_OPS:
                coverage.has_create = True
                if op.source_file and op.source_file not in coverage.create_programs:
                    coverage.create_programs.append(op.source_file)

            elif op_type in CRUDDetector._READ_OPS:
                coverage.has_read = True
                if op.source_file and op.source_file not in coverage.read_programs:
                    coverage.read_programs.append(op.source_file)

            elif op_type in CRUDDetector._UPDATE_OPS:
                coverage.has_update = True
                if op.source_file and op.source_file not in coverage.update_programs:
                    coverage.update_programs.append(op.source_file)

            elif op_type in CRUDDetector._DELETE_OPS:
                coverage.has_delete = True
                if op.source_file and op.source_file not in coverage.delete_programs:
                    coverage.delete_programs.append(op.source_file)

        coverage.is_complete = all([
            coverage.has_create,
            coverage.has_read,
            coverage.has_update,
            coverage.has_delete,
        ])
        coverage.total_operations = len(entity.operations)

        missing = []
        if not coverage.has_create:
            missing.append("create")
        if not coverage.has_read:
            missing.append("read")
        if not coverage.has_update:
            missing.append("update")
        if not coverage.has_delete:
            missing.append("delete")
        coverage.missing_operations = missing

        return coverage

    @staticmethod
    def detect_all(entities: list[EntityDefinition]) -> list[CRUDCoverage]:
        """Analisa todas as entidades e retorna coberturas."""
        return [CRUDDetector.detect(e) for e in entities]

    @staticmethod
    def summary(coverages: list[CRUDCoverage]) -> dict:
        """Resumo estatistico da cobertura CRUD."""
        total = len(coverages)
        complete = sum(1 for c in coverages if c.is_complete)
        partial = total - complete

        by_missing: dict[str, int] = {}
        for c in coverages:
            for missing in c.missing_operations:
                by_missing[missing] = by_missing.get(missing, 0) + 1

        return {
            "total_entities": total,
            "complete_crud": complete,
            "partial_crud": partial,
            "completeness_pct": round(complete / max(1, total) * 100, 1),
            "missing_operations": by_missing,
            "entities_without_create": sum(1 for c in coverages if not c.has_create),
            "entities_without_read": sum(1 for c in coverages if not c.has_read),
            "entities_without_update": sum(1 for c in coverages if not c.has_update),
            "entities_without_delete": sum(1 for c in coverages if not c.has_delete),
        }

"""Classifica campos: tipo, obrigatoriedade, dominio e formato."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .entity_catalog import FieldDefinition


@dataclass
class FieldClassification:
    """Classificacao detalhada de um campo."""
    field_name: str = ""
    original_datatype: str = ""
    inferred_datatype: str = ""  # text, integer, decimal, date, datetime, boolean, code
    is_required: bool = False
    has_unique_constraint: bool = False
    format_mask: str = ""  # PICTURE mask
    domain_values: list[str] = field(default_factory=list)  # VALID/RANGE values
    min_length: int = 0
    max_length: int = 0
    min_value: float = 0.0
    max_value: float = 0.0
    lookup_entity: str = ""  # entidade referenciada (FK implícita)
    semantic_category: str = ""  # cpf, cnpj, email, phone, cep, name, etc.
    confidence: float = 0.0  # 0-1, confianca na classificacao


class FieldClassifier:
    """Classifica campos extraidos do codigo-fonte."""

    # Padroes semanticos por nome de campo
    _SEMANTIC_PATTERNS: list[tuple[str, str, str, float]] = [
        # (regex, datatype, semantic_category, confidence)
        (r"^(cpf|num_cpf|numero_cpf)$", "text", "cpf", 0.95),
        (r"^(cnpj|num_cnpj|numero_cnpj)$", "text", "cnpj", 0.95),
        (r"^(rg|identidade|num_rg)$", "text", "rg", 0.90),
        (r"^(cep|cod_postal|zip)$", "text", "cep", 0.90),
        (r"^(email|e_mail|mail)$", "text", "email", 0.90),
        (r"^(telefone|fone|tel|phone|celular|cel)$", "text", "phone", 0.90),
        (r"^(nome|name|razao|razao_social|fantasia)$", "text", "name", 0.85),
        (r"^(endereco|end|logradouro|rua|av)$", "text", "address", 0.80),
        (r"^(bairro|bairro)$", "text", "neighborhood", 0.80),
        (r"^(cidade|cidade|city|municipio)$", "text", "city", 0.80),
        (r"^(uf|estado|state)$", "text", "state", 0.85),
        (r"^(data|dt_|date_|dta_|dat_|dt_nasc|dt_admissao|dt_emissao)$", "date", "date", 0.90),
        (r"^(hora|hora_|hora)$", "text", "time", 0.80),
        (r"^(codigo|cod_|cd_|id_|chave)$", "integer", "code", 0.85),
        (r"^(valor|vlr|preco|preco|total|saldo)$", "decimal", "money", 0.80),
        (r"^(quantidade|qtd|qtde|estoque)$", "integer", "quantity", 0.80),
        (r"^(peso|altura|volume|metros|kg)$", "decimal", "measure", 0.75),
        (r"^(status|situacao|situacao|tipo)$", "text", "enum", 0.70),
        (r"^(obs|observacao|descricao|desc|complemento)$", "text", "text", 0.70),
        (r"^(flag_|flg_|indicador|ind_|ativo|inativo)$", "boolean", "boolean", 0.80),
    ]

    _RE_PICTURE_NUMERIC = re.compile(r"[9Z#\*\$\.\-,]+", re.IGNORECASE)
    _RE_PICTURE_DATE = re.compile(r"@[DE]\s", re.IGNORECASE)

    @classmethod
    def classify(cls, field: FieldDefinition) -> FieldClassification:
        """Classifica um campo."""
        fc = FieldClassification(
            field_name=field.name,
            original_datatype=field.datatype or "text",
            is_required=field.required,
            has_unique_constraint=field.unique_flag,
            min_length=field.min_length or 0,
            max_length=field.max_length or 0,
            lookup_entity=field.lookup_table or "",
        )

        # Inferir tipo a partir do nome
        cls._infer_semantic(fc)

        # Extrair constraints do PICTURE/VALID
        if field.constraints_json:
            cls._parse_constraints(fc, field.constraints_json)

        # Extrair regras de validacao
        cls._parse_validation_rules(fc, field.validation_rules)

        # Inferir tipo final combinando datatype + semantica
        fc.inferred_datatype = cls._resolve_datatype(fc)

        return fc

    @classmethod
    def _infer_semantic(cls, fc: FieldClassification) -> None:
        name_lower = fc.field_name.lower().strip()
        for pattern, datatype, category, confidence in cls._SEMANTIC_PATTERNS:
            if re.match(pattern, name_lower):
                if confidence > fc.confidence:
                    fc.semantic_category = category
                    fc.confidence = confidence
                    if datatype and fc.original_datatype == "text":
                        fc.inferred_datatype = datatype
                return  # primeira match ganha

    @classmethod
    def _parse_constraints(cls, fc: FieldClassification, constraints_json: str) -> None:
        import json
        try:
            constraints = json.loads(constraints_json)
        except (json.JSONDecodeError, TypeError):
            return

        # PICTURE mask
        picture = str(constraints.get("picture") or constraints.get("format") or "")
        if picture:
            fc.format_mask = picture
            if cls._RE_PICTURE_DATE.search(picture):
                fc.inferred_datatype = "date"
            elif cls._RE_PICTURE_NUMERIC.search(picture):
                fc.inferred_datatype = "decimal" if "." in picture or "," in picture else "integer"

        # RANGE
        if "min" in constraints:
            fc.min_value = float(constraints["min"])
        if "max" in constraints:
            fc.max_value = float(constraints["max"])

        # VALID values
        valid_values = constraints.get("valid") or constraints.get("choices") or []
        if isinstance(valid_values, list):
            fc.domain_values = [str(v) for v in valid_values]
        elif isinstance(valid_values, str):
            fc.domain_values = [v.strip() for v in valid_values.split(",") if v.strip()]

    @classmethod
    def _parse_validation_rules(cls, fc: FieldClassification, rules: list[str]) -> None:
        for rule in rules:
            rule_lower = rule.lower()
            if "not null" in rule_lower or "required" in rule_lower or "obrigat" in rule_lower:
                fc.is_required = True
            if "unique" in rule_lower or "unico" in rule_lower or "primary key" in rule_lower:
                fc.has_unique_constraint = True

    @classmethod
    def _resolve_datatype(cls, fc: FieldClassification) -> str:
        """Resolve tipo final combinando datatype original + semantica + constraints."""
        original = (fc.original_datatype or "text").lower()

        # Se ja inferido por constraints
        if fc.inferred_datatype:
            return fc.inferred_datatype

        # Mapa de tipos originais para normalizados
        type_map = {
            "integer": "integer", "int": "integer", "number": "integer",
            "numeric": "decimal", "decimal": "decimal", "float": "decimal",
            "double": "decimal", "real": "decimal", "money": "decimal",
            "date": "date", "datetime": "datetime", "timestamp": "datetime",
            "boolean": "boolean", "bool": "boolean", "logical": "boolean",
            "text": "text", "varchar": "text", "char": "text",
            "character": "text", "string": "text", "memo": "text",
            "blob": "text", "binary": "text",
        }
        return type_map.get(original, "text")

    @classmethod
    def classify_all(cls, fields: list[FieldDefinition]) -> list[FieldClassification]:
        return [cls.classify(f) for f in fields]

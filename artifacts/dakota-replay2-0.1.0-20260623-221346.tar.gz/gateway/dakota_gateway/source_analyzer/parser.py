from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from .entity_catalog import EntityDefinition, FieldDefinition, OperationDefinition, ScreenDefinition


from .sql_extractor import SQLExtractor
from .isam_extractor import ISAMExtractor
from .dbf_extractor import DBFExtractor
from .recital_extractor import RecitalExtractor
from .validation_extractor import ValidationExtractor
from .screen_extractor import ScreenExtractor
from .crud_detector import CRUDDetector, CRUDCoverage
from .field_classifier import FieldClassifier, FieldClassification
from .relationship_mapper import RelationshipMapper, RelationshipMap
from .menu_analyzer import MenuAnalyzer, MenuTree


class SourceParser:
    """Orquestrador de analise de codigo-fonte: SQL, ISAM, DBF, Recital, validacoes e telas."""

    def __init__(self, source_dir: str):
        self.source_dir = Path(source_dir)
        self._entities: dict[str, EntityDefinition] = {}
        self._screens: list[ScreenDefinition] = []

    # ------------------------------------------------------------------
    # API publica
    # ------------------------------------------------------------------

    def parse_all(self) -> tuple[list[EntityDefinition], list[ScreenDefinition]]:
        for file_path in self._collect_source_files():
            content = file_path.read_text(encoding="utf-8", errors="replace")
            self._parse_file(file_path, content)

        return (list(self._entities.values()), self._screens)

    def entities(self) -> list[EntityDefinition]:
        return list(self._entities.values())

    def screens(self) -> list[ScreenDefinition]:
        return self._screens

    # ------------------------------------------------------------------
    # Discovery Engine — Sprint 2
    # ------------------------------------------------------------------

    def crud_coverage(self) -> list[CRUDCoverage]:
        """Analisa cobertura CRUD de todas as entidades."""
        return CRUDDetector.detect_all(list(self._entities.values()))

    def crud_summary(self) -> dict:
        """Resumo estatistico da cobertura CRUD."""
        return CRUDDetector.summary(self.crud_coverage())

    def classify_fields(self) -> dict[str, list[FieldClassification]]:
        """Classifica campos de todas as entidades."""
        result: dict[str, list[FieldClassification]] = {}
        for entity in self._entities.values():
            result[entity.name] = FieldClassifier.classify_all(entity.fields)
        return result

    def relationships(self) -> RelationshipMap:
        """Mapeia relacionamentos entre entidades."""
        mapper = RelationshipMapper()
        return mapper.map(list(self._entities.values()))

    def menu_tree(self) -> MenuTree:
        """Constroi arvore de navegacao."""
        analyzer = MenuAnalyzer(str(self.source_dir))
        return analyzer.analyze(str(self.source_dir))

    def discovery_report(self) -> dict:
        """Relatorio completo de discovery."""
        crud = self.crud_summary()
        rels = self.relationships()
        menu = self.menu_tree()

        return {
            "entities": len(self._entities),
            "screens": len(self._screens),
            "crud": crud,
            "relationships": {
                "total": len(rels.relationships),
                "orphan_entities": rels.orphan_entities,
                "adjacency": RelationshipMapper.to_adjacency_list(rels),
            },
            "menu": {
                "total_menus": menu.total_menus,
                "total_programs": menu.total_programs,
                "max_depth": menu.max_depth,
                "orphan_programs": menu.orphan_programs,
                "tree": MenuAnalyzer.to_dict(menu.root) if menu.root else None,
            },
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _collect_source_files(self) -> list[Path]:
        extensions = {".prg", ".src", ".sql", ".rsp", ".php", ".scx", ".vcx", ".pjx", ".pjt"}
        files: list[Path] = []
        if self.source_dir.is_file():
            if self.source_dir.suffix.lower() in extensions:
                return [self.source_dir]
            return []
        for ext in extensions:
            files.extend(self.source_dir.rglob(f"*{ext}"))
        return sorted(files)

    def _parse_file(self, file_path: Path, content: str) -> None:
        sql_entities = SQLExtractor.extract(content, str(file_path))
        isam_entities = ISAMExtractor.extract(content, str(file_path))
        dbf_entities = DBFExtractor.extract(content, str(file_path))
        recital_entities = RecitalExtractor.extract(content, str(file_path))

        screens = ScreenExtractor.extract(content, str(file_path))
        self._screens.extend(screens)

        for ent_list in (sql_entities, isam_entities, dbf_entities, recital_entities):
            for ent in ent_list:
                merged = self._merge_entity(ent)
                ValidationExtractor.enrich(merged, content, str(file_path))

    def _merge_entity(self, incoming: EntityDefinition) -> EntityDefinition:
        key = incoming.name.upper()
        if key in self._entities:
            existing = self._entities[key]
            existing_fields = {f.name.upper() for f in existing.fields}
            for f in incoming.fields:
                if f.name.upper() not in existing_fields:
                    existing.fields.append(f)
            existing.operations.extend(incoming.operations)
            existing.indexes.extend(incoming.indexes)
            if incoming.storage_type != "unknown":
                existing.storage_type = incoming.storage_type
            return existing
        else:
            self._entities[key] = incoming
            return incoming

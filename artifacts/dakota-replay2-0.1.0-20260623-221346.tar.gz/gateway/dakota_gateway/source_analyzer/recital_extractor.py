"""Recital 8.0 Entity Extractor — Inferencia Inteligente.

Infere entidades de codigo Recital/Dakota usando heurísticas com
pontuacao acumulativa. Principais fontes de inferencia:

1. Funcoes de abertura (XxxAbreNNN) → modulo + tabela (score 10)
2. Referencias via seta (alias->campo) → entidade ativa (score 1 cada)
3. Selecao de area (select("alias")) → entidade referenciada (score 3)
4. Fechamento (close alias) → confirma entidade (score 2)
5. USE ... ALIAS → abertura direta (score 8)
6. SQL embutido (SELECT ... FROM) → score 4
7. Frequencia acumulada → score total de confianca

Agrupa por prefixo de modulo e armazena dominio via metadata_json.
"""

from __future__ import annotations

import json
import re
from typing import Dict, List, Set

from .entity_catalog import EntityDefinition, OperationDefinition

_MODULO_NAMES: Dict[str, str] = {
    "cad": "cadastros", "cre": "contas_receber", "est": "estoque",
    "fat": "faturamento", "ped": "pedidos", "pcp": "producao",
    "cmp": "compras", "fin": "financeiro", "exp": "expedicao",
    "mat": "materiais", "sig": "sistema", "blo": "bloqueio",
    "uni": "unificado", "sol": "solados", "sgm": "gestao_modelos",
    "ses": "sesmt", "ctb": "contabilidade", "imo": "imoveis",
    "sac": "sac", "mkt": "marketing", "loj": "lojas",
    "cpr": "compras", "ndm": "nota_devolucao", "mao": "mao_de_obra",
}

_STOP_WORDS: Set[str] = {
    "if", "else", "endif", "function", "return", "parameters", "private",
    "public", "do", "while", "enddo", "case", "endcase", "for", "endfor",
    "scan", "endscan", "with", "endwhile", "iif",
    "set", "declare", "local", "dimension", "text", "endtext",
    "lareaant", "lok", "labrarq", "lareares", "larea",
}


def _infer_modulo(alias: str) -> str:
    low = alias.lower()
    for prefix, nome in sorted(_MODULO_NAMES.items(), key=lambda x: -len(x[0])):
        if low.startswith(prefix):
            return nome
    return ""


def _is_likely_entity(alias: str) -> bool:
    low = alias.lower()
    if low in _STOP_WORDS:
        return False
    if len(alias) < 3 or len(alias) > 20:
        return False
    if not re.search(r"[a-z]", low):
        return False
    return True


def _get_meta(ent: EntityDefinition) -> dict:
    try:
        return json.loads(ent.metadata_json) if ent.metadata_json else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def _set_meta(ent: EntityDefinition, data: dict) -> None:
    ent.metadata_json = json.dumps(data)


class RecitalExtractor:
    """Extrai entidades de codigo Recital 8.0 usando inferencia inteligente."""

    @staticmethod
    def extract(content: str, source_file: str = "") -> list[EntityDefinition]:
        inferred: Dict[str, dict] = {}
        lines = content.split("\n")

        for line_no, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("*") or stripped.startswith("&&"):
                continue

            # 1. XxxAbreNNN(flag) → abertura de tabela (score maximo)
            m = re.search(r"(\w+)Abre(\d+)\s*\(\s*\d+\s*\)", line, re.IGNORECASE)
            if m:
                alias = (m.group(1) + m.group(2)).lower()
                RecitalExtractor._record(inferred, alias, "open", source_file, line_no,
                                         _infer_modulo(alias), score=10)

            # 2. USE arquivo [ALIAS nome]
            m = re.search(r"use\s+(\S+)", line, re.IGNORECASE)
            if m:
                alias_m = re.search(r"alias\s+(\w+)", line, re.IGNORECASE)
                alias = (alias_m.group(1) if alias_m else m.group(1).split(".")[0]).lower()
                if _is_likely_entity(alias):
                    RecitalExtractor._record(inferred, alias, "use", source_file, line_no,
                                             _infer_modulo(alias), score=8)

            # 3. alias->campo (cada mencao soma 1)
            for arrow_m in re.finditer(r"(\w{3,15})->\w+", line):
                alias = arrow_m.group(1).lower()
                if _is_likely_entity(alias):
                    RecitalExtractor._record(inferred, alias, "reference", source_file, line_no,
                                             _infer_modulo(alias), score=1)

            # 4. select("alias")
            for sel_m in re.finditer(r'select\s*\(\s*"(\w+)"\s*\)', line, re.IGNORECASE):
                alias = sel_m.group(1).lower()
                if _is_likely_entity(alias):
                    RecitalExtractor._record(inferred, alias, "select", source_file, line_no,
                                             _infer_modulo(alias), score=3)

            # 5. close alias
            m = re.match(r"close\s+(\w{3,15})", stripped, re.IGNORECASE)
            if m:
                alias = m.group(1).lower()
                if _is_likely_entity(alias):
                    RecitalExtractor._record(inferred, alias, "close", source_file, line_no,
                                             _infer_modulo(alias), score=2)

            # 6. SELECT SQL FROM tabela
            m = re.search(r"from\s+(\w+)", line, re.IGNORECASE)
            if m and re.search(r"select\s+", line, re.IGNORECASE):
                table = m.group(1).lower()
                if _is_likely_entity(table) and "dual" not in table:
                    RecitalExtractor._record(inferred, table, "select_sql", source_file, line_no,
                                             _infer_modulo(table), score=4)

        # Consolida entidades ordenadas por score
        entities: List[EntityDefinition] = []
        for alias, info in sorted(inferred.items(), key=lambda x: -x[1]["score"]):
            ent = EntityDefinition(
                name=alias,
                storage_type="recital",
                source=source_file,
            )
            _set_meta(ent, {
                "_score": info["score"],
                "_module": info.get("modulo", ""),
            })
            for op in info["ops"]:
                ent.operations.append(
                    OperationDefinition(
                        operation_type=op["type"],
                        entity_name=alias,
                        source_file=op["source"],
                        line_number=op["line"],
                    )
                )
            entities.append(ent)

        return entities

    @staticmethod
    def _record(inferred: Dict, alias: str, op_type: str,
                source: str, line: int, modulo: str = "", score: int = 1):
        if alias not in inferred:
            inferred[alias] = {"ops": [], "modulo": modulo, "score": 0}
        inferred[alias]["ops"].append({"type": op_type, "source": source, "line": line})
        inferred[alias]["score"] += score
        if modulo and (
            not inferred[alias].get("modulo")
            or len(modulo) > len(inferred[alias].get("modulo", ""))
        ):
            inferred[alias]["modulo"] = modulo

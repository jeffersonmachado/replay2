"""Mapeia relacionamentos entre entidades: FK, lookup tables, referencias cruzadas."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from .entity_catalog import EntityDefinition, FieldDefinition


@dataclass
class Relationship:
    """Relacionamento entre duas entidades."""
    source_entity: str = ""
    target_entity: str = ""
    relationship_type: str = ""  # foreign_key, lookup, reference, join
    source_field: str = ""
    target_field: str = ""
    cardinality: str = ""  # 1:1, 1:N, N:M
    source_file: str = ""
    confidence: float = 0.0


@dataclass
class RelationshipMap:
    """Mapa completo de relacionamentos do sistema."""
    relationships: list[Relationship] = field(default_factory=list)
    entity_graph: dict[str, list[str]] = field(default_factory=dict)
    orphan_entities: list[str] = field(default_factory=list)


class RelationshipMapper:
    """Mapeia relacionamentos entre entidades a partir de codigo-fonte."""

    _RE_FK_FIELD = re.compile(
        r"^(id_|cod_|cd_|fk_|ref_|chave_)(\w+)$", re.IGNORECASE
    )
    _RE_LOOKUP_REF = re.compile(
        r"LOOKUP\s+TO\s+(\w+)", re.IGNORECASE
    )

    def map(self, entities: list[EntityDefinition]) -> RelationshipMap:
        """Analisa todas as entidades e mapeia relacionamentos."""
        result = RelationshipMap()
        entity_names = {e.name.upper() for e in entities}

        for entity in entities:
            entity_rels: list[str] = []

            for field in entity.fields:
                rels = self._detect_field_relationships(field, entity.name, entities)
                for rel in rels:
                    if rel.target_entity.upper() in entity_names:
                        result.relationships.append(rel)
                        entity_rels.append(rel.target_entity)

            result.entity_graph[entity.name] = sorted(set(entity_rels))

        # Entidades sem relacionamentos
        result.orphan_entities = sorted(
            name for name, rels in result.entity_graph.items() if not rels
        )

        return result

    def _detect_field_relationships(
        self,
        field: FieldDefinition,
        entity_name: str,
        all_entities: list[EntityDefinition],
    ) -> list[Relationship]:
        rels: list[Relationship] = []

        # 1. Lookup table explicita
        if field.lookup_table:
            rels.append(Relationship(
                source_entity=entity_name,
                target_entity=field.lookup_table,
                relationship_type="lookup",
                source_field=field.name,
                confidence=0.9,
            ))
            return rels

        # 2. FK por nome: id_cliente -> CLIENTES
        fk_match = self._RE_FK_FIELD.match(field.name)
        if fk_match:
            target_name = fk_match.group(2).upper()
            # Procurar entidade correspondente
            for e in all_entities:
                if e.name.upper() == target_name or e.name.upper().startswith(target_name):
                    rels.append(Relationship(
                        source_entity=entity_name,
                        target_entity=e.name,
                        relationship_type="foreign_key",
                        source_field=field.name,
                        target_field="id" if e.name.upper() == target_name else "",
                        cardinality="N:1",
                        confidence=0.85 if e.name.upper() == target_name else 0.7,
                    ))
                    break

        # 3. FK por nome do campo == nome de outra entidade
        field_upper = field.name.upper()
        for e in all_entities:
            if e.name.upper() == field_upper and e.name.upper() != entity_name.upper():
                rels.append(Relationship(
                    source_entity=entity_name,
                    target_entity=e.name,
                    relationship_type="foreign_key",
                    source_field=field.name,
                    cardinality="N:1",
                    confidence=0.75,
                ))

        return rels

    @staticmethod
    def to_adjacency_list(rmap: RelationshipMap) -> dict[str, list[dict]]:
        """Converte para lista de adjacencia (formato vizualizavel)."""
        adj: dict[str, list[dict]] = {}
        for rel in rmap.relationships:
            adj.setdefault(rel.source_entity, []).append({
                "target": rel.target_entity,
                "type": rel.relationship_type,
                "source_field": rel.source_field,
                "target_field": rel.target_field,
                "cardinality": rel.cardinality,
            })
        return adj

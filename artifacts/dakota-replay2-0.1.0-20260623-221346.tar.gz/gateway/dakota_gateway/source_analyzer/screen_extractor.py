from __future__ import annotations

import re

from .entity_catalog import ScreenDefinition, FieldDefinition

# Padroes para deteccao de definicoes de tela
_RE_SCREEN_DEFINE = re.compile(
    r"(?:DEFINE\s+(?:WINDOW|SCREEN|FORM)|@\s+\d+\s*,\s*\d+\s+(?:SAY|GET|PROMPT))",
    re.IGNORECASE,
)
_RE_PROMPT_LINE = re.compile(
    r"@\s+\d+\s*,\s*\d+\s+(?:SAY|GET)\s+['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)
_RE_GET_FIELD = re.compile(
    r"@\s+\d+\s*,\s*\d+\s+GET\s+(\w+)",
    re.IGNORECASE,
)
_RE_TITLE = re.compile(
    r"(?:TITLE|TITULO|CAPTION)\s+['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)
_RE_PROGRAM_BLOCK = re.compile(
    r"(?:PROCEDURE|FUNCTION|PROGRAM)\s+(\w+)",
    re.IGNORECASE,
)
_RE_MENU_OPTION = re.compile(
    r"(?:PROMPT|MENU\s+OPTION)\s+['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)
_RE_VALID_CLAUSE = re.compile(
    r"VALID\s+(.+?)(?:\s+(?:ERROR|MESSAGE|WHEN|PICTURE|RANGE|COLOR))",
    re.IGNORECASE,
)
_RE_PICTURE_CLAUSE = re.compile(
    r"PICTURE\s+['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)


class ScreenExtractor:
    """Extrai definicoes de telas a partir de codigo-fonte legado."""

    @staticmethod
    def extract(content: str, source_file: str = "") -> list[ScreenDefinition]:
        screens: list[ScreenDefinition] = []
        lines = content.split("\n")
        current_screen: ScreenDefinition | None = None
        current_program: str = ""
        screen_start = 0

        for line_no, line in enumerate(lines, 1):
            # Detectar inicio de bloco de programa
            pm = _RE_PROGRAM_BLOCK.search(line)
            if pm:
                current_program = pm.group(1)
                continue

            # Detectar definicao de tela
            if _RE_SCREEN_DEFINE.search(line):
                if current_screen is None:
                    current_screen = ScreenDefinition(
                        program_name=current_program,
                        source_file=source_file,
                        source_lines=(line_no, line_no),
                    )
                    screen_start = line_no
                current_screen.source_lines = (screen_start, line_no)
                continue

            # Extrair titulo
            if current_screen:
                tm = _RE_TITLE.search(line)
                if tm and not current_screen.title:
                    current_screen.title = tm.group(1)

            # Extrair prompt/GET
            if current_screen:
                pm = _RE_PROMPT_LINE.search(line)
                gm = _RE_GET_FIELD.search(line)
                if gm:
                    field_name = gm.group(1)
                    prompt_text = pm.group(1) if pm else field_name
                    if field_name.upper() not in {f.name.upper() for f in current_screen.fields}:
                        current_screen.fields.append(
                            FieldDefinition(name=field_name, prompt=prompt_text)
                        )

            # Fim do bloco de tela (linha em branco apos varias definicoes)
            if current_screen and line.strip() == "" and len(current_screen.fields) > 0:
                # Verifica se a proxima linha nao eh mais definicao
                pass

        # Finaliza ultima tela
        if current_screen and current_screen.fields:
            screens.append(current_screen)

        return screens

from __future__ import annotations

from .schema import SyntheticSchema, FieldSchema, ScreenSchema
from .engine import SyntheticEngine
from .providers import (
    DataProvider,
    ProviderRegistry,
    person_name_provider,
    company_name_provider,
    cpf_provider,
    cnpj_provider,
    rg_provider,
    phone_provider,
    email_provider,
    address_provider,
    cep_provider,
    date_provider,
    datetime_provider,
    number_provider,
    decimal_provider,
    money_provider,
    choice_provider,
    boolean_provider,
    uuid_provider,
    sequence_provider,
    text_provider,
    code_provider,
)
from .constraints import ConstraintValidator, ConstraintRule
from .dataset_builder import DatasetBuilder, Dataset, DatasetRecord
from .template_engine import TemplateEngine
from .inferencer import SyntheticInferencer
from .screen_registry import ScreenRegistry
from .journey import JourneyDefinition, JourneyStep, JourneyDataset
from .journey_inferencer import JourneyInferencer
from .journey_builder import JourneyBuilder
from .error_detector import ErrorDetector, DetectedError
from .journey_verifier import JourneyVerifier, JourneyVerificationResult
from .capture_parametrizer import CaptureParametrizer, CaptureTemplate, ParametrizedSession
from .stress_runner import SyntheticStressRunner, SyntheticStressConfig, StressRunResult
from .expanded_inferencer import ExpandedInferencer, ConditionalFlow, DataDependency, TransactionBlock
from .replay_adapter import ReplayAdapter, ReplayAdapterConfig
from .homologation_report import HomologationReport
from .macro_journey import MacroJourneyRunner, MacroJourneyDefinition, MacroJourneyStep, MacroJourneyResult
from .screen_differ import ScreenDiffer, ScreenDiff, ScreenDiffLine
from .remote_executor import RemoteExecutor, RemoteSessionResult, RemoteExecutionResult
from .scheduler import Scheduler, ScheduleConfig, RegressionComparison
from .session_recorder import SessionRecorder, RecordedSession
from .screen_explorer import ScreenExplorer, DiscoveredScreen, ExplorationResult
from .junit_exporter import JUnitExporter
from .snapshot_baseline import SnapshotBaseline, ScreenSnapshot, BaselineComparison
from .csv_exporter import CSVExporter, QuickstartDiffer, QuickstartDiff, WatchMode, MetricsCollector
from .crud_journey_generator import CRUDJourneyGenerator, CRUDJourneyConfig
from .ddl_parser import DDLParser, DDLParseResult
from .journey_validator import JourneyValidator, JourneyValidation
from .smart_provider_router import SmartProviderRouter
from .relationship_resolver import RelationshipResolver, ResolvedForeignKey, ResolvedLookup
from .integrated_pipeline import IntegratedPipeline, PipelineResult

__all__ = [
    "SyntheticSchema",
    "FieldSchema",
    "ScreenSchema",
    "SyntheticEngine",
    "DataProvider",
    "ProviderRegistry",
    "person_name_provider",
    "company_name_provider",
    "cpf_provider",
    "cnpj_provider",
    "rg_provider",
    "phone_provider",
    "email_provider",
    "address_provider",
    "cep_provider",
    "date_provider",
    "datetime_provider",
    "number_provider",
    "decimal_provider",
    "money_provider",
    "choice_provider",
    "boolean_provider",
    "uuid_provider",
    "sequence_provider",
    "text_provider",
    "code_provider",
    "ConstraintValidator",
    "ConstraintRule",
    "DatasetBuilder",
    "Dataset",
    "DatasetRecord",
    "TemplateEngine",
    "SyntheticInferencer",
    "ScreenRegistry",
    "JourneyDefinition",
    "JourneyStep",
    "JourneyDataset",
    "JourneyInferencer",
    "JourneyBuilder",
    "ErrorDetector",
    "DetectedError",
    "JourneyVerifier",
    "JourneyVerificationResult",
    "CaptureParametrizer",
    "CaptureTemplate",
    "ParametrizedSession",
    "SyntheticStressRunner",
    "SyntheticStressConfig",
    "StressRunResult",
    "ExpandedInferencer",
    "ConditionalFlow",
    "DataDependency",
    "TransactionBlock",
    "ReplayAdapter",
    "ReplayAdapterConfig",
    "HomologationReport",
    "MacroJourneyRunner",
    "MacroJourneyDefinition",
    "MacroJourneyStep",
    "MacroJourneyResult",
    "ScreenDiffer",
    "ScreenDiff",
    "ScreenDiffLine",
    "RemoteExecutor",
    "RemoteSessionResult",
    "RemoteExecutionResult",
    "Scheduler",
    "ScheduleConfig",
    "RegressionComparison",
    "SessionRecorder",
    "RecordedSession",
    "ScreenExplorer",
    "DiscoveredScreen",
    "ExplorationResult",
    "JUnitExporter",
    "SnapshotBaseline",
    "ScreenSnapshot",
    "BaselineComparison",
    "CSVExporter",
    "QuickstartDiffer",
    "QuickstartDiff",
    "WatchMode",
    "MetricsCollector",
    "CRUDJourneyGenerator",
    "CRUDJourneyConfig",
    "DDLParser",
    "DDLParseResult",
    "JourneyValidator",
    "JourneyValidation",
    "SmartProviderRouter",
    "RelationshipResolver",
    "ResolvedForeignKey",
    "ResolvedLookup",
    "IntegratedPipeline",
    "PipelineResult",
]

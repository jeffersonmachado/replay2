"""Pipeline integrado: Discovery → Journey → Synthetic em uma unica chamada."""
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ..source_analyzer.parser import SourceParser
from ..source_analyzer.crud_detector import CRUDDetector
from ..source_analyzer.field_classifier import FieldClassifier
from ..source_analyzer.relationship_mapper import RelationshipMapper
from ..source_analyzer.menu_analyzer import MenuAnalyzer
from .crud_journey_generator import CRUDJourneyGenerator, CRUDJourneyConfig
from .ddl_parser import DDLParser
from .journey_validator import JourneyValidator
from .smart_provider_router import SmartProviderRouter
from .relationship_resolver import RelationshipResolver
from .dataset_builder import DatasetBuilder, Dataset
from .journey_builder import JourneyBuilder
from .journey import JourneyDefinition
from .schema import ScreenSchema


@dataclass
class PipelineResult:
    """Resultado completo do pipeline."""
    source_dir: str = ""
    # Discovery
    entities_count: int = 0
    screens_count: int = 0
    crud_summary: dict = field(default_factory=dict)
    relationships_count: int = 0
    menu_programs: int = 0
    # Journey
    journeys_generated: int = 0
    journeys_saved: int = 0
    # Synthetic
    datasets_generated: int = 0
    # Validation
    validation_summary: dict = field(default_factory=dict)
    # Timing
    duration_ms: int = 0
    # Warnings
    warnings: list[str] = field(default_factory=list)
    # Detail
    detail: dict = field(default_factory=dict)


class IntegratedPipeline:
    """Orquestrador do pipeline completo de validacao."""

    def __init__(self, db_connection: Optional[sqlite3.Connection] = None):
        self.con = db_connection
        self.router = SmartProviderRouter()
        self.resolver = RelationshipResolver()
        self.validator = JourneyValidator()

    def run(
        self,
        source_dir: str,
        *,
        save_to_db: bool = True,
        session_count: int = 10,
        seed: int = 0,
    ) -> PipelineResult:
        """Executa o pipeline completo."""
        import time
        start_ms = int(time.time() * 1000)

        result = PipelineResult(source_dir=source_dir)

        # ------------------------------------------------------------------
        # Fase 1: Discovery
        # ------------------------------------------------------------------
        parser = SourceParser(source_dir)
        entities, screens = parser.parse_all()

        if not entities:
            result.warnings.append("nenhuma entidade encontrada no codigo fonte")
            # Tenta DDL
            ddl_parser = DDLParser()
            ddl_result = ddl_parser.parse_directory(source_dir)
            if ddl_result.entities:
                entities = ddl_result.entities
                screens_schemas = ddl_result.screen_schemas
                result.warnings.append(f"entidades extraidas apenas de DDL: {len(entities)}")

        result.entities_count = len(entities)
        result.screens_count = len(screens)

        # CRUD
        coverages = CRUDDetector.detect_all(entities)
        crud_summary = CRUDDetector.summary(coverages)
        result.crud_summary = crud_summary

        # Classify fields
        classifications: dict[str, list] = {}
        for entity in entities:
            classifications[entity.name] = FieldClassifier.classify_all(entity.fields)

        # Relationships
        rels = parser.relationships()
        result.relationships_count = len(rels.relationships)

        # Menu
        menu = parser.menu_tree()
        result.menu_programs = menu.total_programs

        # ------------------------------------------------------------------
        # Fase 2: Journey Generation
        # ------------------------------------------------------------------
        gen = CRUDJourneyGenerator()
        journeys = gen.generate_all(entities, coverages, classifications)
        result.journeys_generated = len(journeys)

        journey_builder = JourneyBuilder(db_connection=self.con) if self.con else None
        saved = 0

        for journey in journeys:
            if save_to_db and journey_builder:
                try:
                    journey_builder.save_journey(journey)
                    saved += 1
                except Exception:
                    pass

        result.journeys_saved = saved

        # ------------------------------------------------------------------
        # Fase 3: Synthetic Data
        # ------------------------------------------------------------------
        dataset_builder = DatasetBuilder() if self.con else None
        datasets_count = 0

        if save_to_db and self.con and dataset_builder:
            for journey in journeys:
                try:
                    jds = journey_builder.build_journey_dataset(
                        journey, session_count=session_count, seed=seed
                    )
                    datasets_count += 1
                except Exception:
                    pass

        result.datasets_generated = datasets_count

        # ------------------------------------------------------------------
        # Fase 4: Validation
        # ------------------------------------------------------------------
        entity_map = {e.name: e for e in entities}
        validations = self.validator.validate_all(journeys, entity_map)
        result.validation_summary = self.validator.summary(validations)

        # Detail
        result.detail = {
            "entities": [e.name for e in entities[:20]],
            "complete_crud_entities": [
                c.entity_name for c in coverages if c.is_complete
            ],
            "journey_ids": [j.journey_id for j in journeys[:20]],
            "top_issues": result.validation_summary.get("top_issues", []),
        }

        result.duration_ms = int(time.time() * 1000) - start_ms
        return result

    def run_and_report(self, source_dir: str, **kwargs) -> dict:
        """Executa o pipeline e retorna relatorio em dicionario."""
        result = self.run(source_dir, **kwargs)
        return {
            "source_dir": result.source_dir,
            "duration_ms": result.duration_ms,
            "discovery": {
                "entities": result.entities_count,
                "screens": result.screens_count,
                "crud": result.crud_summary,
                "relationships": result.relationships_count,
                "menu_programs": result.menu_programs,
            },
            "journeys": {
                "generated": result.journeys_generated,
                "saved": result.journeys_saved,
            },
            "synthetic": {
                "datasets_generated": result.datasets_generated,
            },
            "validation": result.validation_summary,
            "warnings": result.warnings,
            "detail": result.detail,
        }

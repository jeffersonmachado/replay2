"""Roteador inteligente: field → DataProvider baseado em nome, tipo, formato e contexto."""
from __future__ import annotations

import re
from typing import Any, Optional

from .providers import (
    DataProvider,
    ProviderRegistry,
    default_registry,
)
from .schema import FieldSchema
from ..source_analyzer.field_classifier import FieldClassification


class SmartProviderRouter:
    """Roteia campos para providers de dados sinteticos usando inferencia contextual.

    Estrategia de resolucao (em ordem de prioridade):
    1. Nome do campo → provider especifico (cpf, cnpj, email, etc.)
    2. Formato/PICTURE → provider (mascara 999.999.999-99 → cpf)
    3. Tipo de dados → provider (integer → number, decimal → money)
    4. Contexto da entidade → provider (entidade "clientes" + campo "documento" → cpf)
    5. Choices/domain → choice provider
    6. Fallback → text provider
    """

    # Mapa direto: padrao no nome → provider
    _NAME_PATTERNS: list[tuple[re.Pattern, str, float]] = [
        (re.compile(r"^cpf$", re.IGNORECASE), "cpf", 0.95),
        (re.compile(r"(num_?)?cpf$", re.IGNORECASE), "cpf", 0.90),
        (re.compile(r"^cnpj$", re.IGNORECASE), "cnpj", 0.95),
        (re.compile(r"(num_?)?cnpj$", re.IGNORECASE), "cnpj", 0.90),
        (re.compile(r"^rg$", re.IGNORECASE), "rg", 0.90),
        (re.compile(r"(num_?)?rg|identidade|doc_?identidade$", re.IGNORECASE), "rg", 0.85),
        (re.compile(r"^cep$", re.IGNORECASE), "cep", 0.90),
        (re.compile(r"cod_?postal|zip_?code$", re.IGNORECASE), "cep", 0.85),
        (re.compile(r"^email$|^e_?mail$", re.IGNORECASE), "email", 0.90),
        (re.compile(r"^(telefone|fone|tel|phone|celular|cel)$", re.IGNORECASE), "phone", 0.90),
        (re.compile(r"^(nome|name|razao|razao_social|fantasia)$", re.IGNORECASE), "person_name", 0.85),
        (re.compile(r"^(endereco|end|logradouro|rua|av)$", re.IGNORECASE), "address", 0.85),
        (re.compile(r"^(bairro)$", re.IGNORECASE), "text", 0.70),
        (re.compile(r"^(cidade|city|municipio)$", re.IGNORECASE), "text", 0.70),
        (re.compile(r"^(uf|estado|state)$", re.IGNORECASE), "text", 0.80),
        (re.compile(r"^(data|dt_|date_|dta_|dat_)", re.IGNORECASE), "date", 0.90),
        (re.compile(r"^hora$|^hora_", re.IGNORECASE), "datetime", 0.80),
        (re.compile(r"^(codigo|cod_|cd_|id_|chave)$", re.IGNORECASE), "code", 0.85),
        (re.compile(r"^(valor|vlr|preco|total|saldo|preco)_?", re.IGNORECASE), "money", 0.80),
        (re.compile(r"^(quantidade|qtd|qtde|estoque)$", re.IGNORECASE), "number", 0.80),
        (re.compile(r"^(peso|altura|volume|metros|kg)$", re.IGNORECASE), "decimal", 0.75),
        (re.compile(r"^(status|situacao|tipo)$", re.IGNORECASE), "choice", 0.70),
        (re.compile(r"^(obs|observacao|descricao|desc|complemento)$", re.IGNORECASE), "text", 0.70),
        (re.compile(r"^(flag_|flg_|indicador|ind_|ativo|inativo)$", re.IGNORECASE), "boolean", 0.80),
    ]

    # Mapa: tipo de dados → provider
    _TYPE_MAP: dict[str, str] = {
        "integer": "number",
        "int": "number",
        "number": "number",
        "decimal": "decimal",
        "float": "decimal",
        "double": "decimal",
        "money": "money",
        "date": "date",
        "datetime": "datetime",
        "timestamp": "datetime",
        "boolean": "boolean",
        "bool": "boolean",
        "text": "text",
        "varchar": "text",
        "char": "text",
    }

    # Contexto: entidade → campo → provider sugerido
    _CONTEXT_MAP: dict[str, dict[str, str]] = {
        "clientes": {"documento": "cpf", "doc": "cpf", "registro": "cpf"},
        "fornecedores": {"documento": "cnpj", "doc": "cnpj", "registro": "cnpj"},
        "empresas": {"documento": "cnpj", "doc": "cnpj"},
        "funcionarios": {"documento": "cpf", "doc": "cpf", "pis": "code"},
        "produtos": {"codigo": "code", "cod": "code", "ean": "code"},
        "notas": {"numero": "number", "serie": "code"},
        "pedidos": {"numero": "number"},
    }

    def __init__(self, registry: Optional[ProviderRegistry] = None):
        self.registry = registry or default_registry()

    def resolve(
        self,
        field: FieldSchema,
        entity_name: str = "",
        classification: Optional[FieldClassification] = None,
    ) -> DataProvider:
        """Resolve o melhor provider para um campo.

        Args:
            field: Schema do campo
            entity_name: Nome da entidade (para contexto)
            classification: Classificacao pre-existente do FieldClassifier
        """
        field_name = (field.name or "").lower().strip()
        best_provider = "text"
        best_confidence = 0.0

        # 1. Matching por nome
        for pattern, provider_name, confidence in self._NAME_PATTERNS:
            if pattern.match(field_name):
                if confidence > best_confidence:
                    best_provider = provider_name
                    best_confidence = confidence
                break  # primeiro match ganha

        # 2. Matching por formato/PICTURE
        if best_confidence < 0.9 and field.format:
            fmt_provider = self._resolve_by_format(field.format)
            if fmt_provider and 0.95 > best_confidence:
                best_provider = fmt_provider
                best_confidence = 0.95

        # 3. Matching por tipo de dados
        if best_confidence < 0.8:
            dtype = (field.datatype or "text").lower()
            type_provider = self._TYPE_MAP.get(dtype)
            if type_provider and 0.7 > best_confidence:
                best_provider = type_provider
                best_confidence = 0.7

        # 4. Matching por contexto (entidade + campo)
        if best_confidence < 0.9 and entity_name:
            entity_lower = entity_name.lower()
            for ctx_entity, field_map in self._CONTEXT_MAP.items():
                if ctx_entity in entity_lower or entity_lower in ctx_entity:
                    for ctx_field, ctx_provider in field_map.items():
                        if ctx_field in field_name and 0.85 > best_confidence:
                            best_provider = ctx_provider
                            best_confidence = 0.85
                            break

        # 5. Se tem choices definidos, usar choice provider
        if field.choices:
            best_provider = "choice"
            best_confidence = 1.0

        return self.registry.get(best_provider)

    def resolve_all(
        self,
        fields: list[FieldSchema],
        entity_name: str = "",
        classifications: Optional[list[FieldClassification]] = None,
    ) -> list[DataProvider]:
        """Resolve providers para todos os campos de uma entidade."""
        providers: list[DataProvider] = []
        for i, field in enumerate(fields):
            classification = classifications[i] if classifications and i < len(classifications) else None
            providers.append(self.resolve(field, entity_name, classification))
        return providers

    @staticmethod
    def _resolve_by_format(field_format: str) -> Optional[str]:
        """Resolve provider a partir do formato/mascara."""
        fmt = str(field_format or "").strip().lower()

        # CPF: 999.999.999-99
        if re.match(r"^\d{3}\.\d{3}\.\d{3}-\d{2}$", fmt):
            return "cpf"
        # CNPJ: 99.999.999/9999-99
        if re.match(r"^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$", fmt):
            return "cnpj"
        # CEP: 99999-999
        if re.match(r"^\d{5}-\d{3}$", fmt):
            return "cep"
        # Telefone: (99) 99999-9999
        if re.match(r"^\(?\d{2}\)?\s?\d{4,5}-?\d{4}$", fmt):
            return "phone"
        # Data: 99/99/9999 ou 9999-99-99
        if re.match(r"^\d{2}/\d{2}/\d{4}$", fmt) or re.match(r"^\d{4}-\d{2}-\d{2}$", fmt):
            return "date"
        # Email
        if "@" in fmt:
            return "email"
        # Numerico puro: 999.999,99
        if re.match(r"^[\d\.,]+$", fmt):
            return "decimal"

        return None

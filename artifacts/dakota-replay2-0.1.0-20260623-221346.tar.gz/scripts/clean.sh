#!/bin/sh
set -eu

info() { printf '%s\n' "$*"; }

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"

# Remove somente artefatos NÃO-oficiais/temporários.
rm -rf "$ROOT_DIR/tests/tmp" 2>/dev/null || true

# Cache Python (não deve ir para distribuição)
rm -rf \
  "$ROOT_DIR/gateway/__pycache__" \
  "$ROOT_DIR/gateway/dakota_gateway/__pycache__" \
  "$ROOT_DIR/gateway/control/__pycache__" \
  "$ROOT_DIR/gateway/tests/__pycache__" \
  "$ROOT_DIR/dashboard/__pycache__" 2>/dev/null || true

# Arquivos de banco de dados e estado local
find "$ROOT_DIR" \
  -name "*.db" \
  -o -name "*.db-wal" \
  -o -name "*.db-shm" \
  -o -name "*.pyc" \
  2>/dev/null | xargs rm -f || true

if [ -d "$ROOT_DIR/dist" ]; then
  # Mantém dist/*.tar.gz (artefato oficial), remove o resto.
  for f in "$ROOT_DIR/dist/"*; do
    [ -e "$f" ] || continue
    case "$f" in
      *.tar.gz) : ;;
      *) rm -rf -- "$f" ;;
    esac
  done
fi

# Metadados locais do editor (se reaparecerem)
if [ -d "$ROOT_DIR/.cursor" ]; then
  rmdir "$ROOT_DIR/.cursor" 2>/dev/null || true
fi

info "OK: limpeza concluída."

